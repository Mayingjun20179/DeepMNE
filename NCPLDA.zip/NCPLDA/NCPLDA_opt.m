function scores = NCPLDA_opt(DATA,cv_data)

train_set = DATA.interaction.*cv_data{1};   %ѵ������

LD_adjmat = train_set;
disSim = DATA.dis_inf.tree_sim;

lncSim=miRNASS( LD_adjmat, disSim );

disSim01  = GSD( LD_adjmat );
lncSim01  = GSM( LD_adjmat );

disSim02  = combineSim(disSim,disSim01);
lncSim02  = combineSim(lncSim,lncSim01);

KK=10;
r=0.4;
ld_adjmat_new=WKNKN( LD_adjmat, lncSim, disSim, KK, r );

matPredict=NCPLDA(lncSim02, disSim02, ld_adjmat_new);

test_data = cv_data{2};
scores = arrayfun(@(x,y)tx_opt(matPredict,x,y),test_data(:,1),test_data(:,2));

end

function c = tx_opt(A,b,c)
c = A(b,c);
end


function [ miRNA_gsSim ] = GSM( md_adjMat )
%GSM Summary of this function goes here
%   Detailed explanation goes here

nm=size(md_adjMat,1);
normSum=0;
for i=1:nm
    
   normSum=normSum+ ((norm(md_adjMat(i,:),2)).^2);
    
end

rm=1/(normSum/nm);

miRNA_gsSim=zeros(nm,nm);

for i=1:nm
   for j=1:nm
       sub=md_adjMat(i,:)-md_adjMat(j,:);
       miRNA_gsSim(i,j)=exp(-rm*((norm(sub,2)).^2));
       
   end 
    
end


end

function [ disease_gsSim ] = GSD( md_adjMat )
%GSD Summary of this function goes here
%   Detailed explanation goes here
    
nd=size(md_adjMat,2);
normSum=0;
for i=1:nd
    
   normSum=normSum+ ((norm(md_adjMat(:,i),2)).^2);
    
end

rd=1/(normSum/nd);

disease_gsSim=zeros(nd,nd);

for i=1:nd
   for j=1:nd
       sub=md_adjMat(:,i)-md_adjMat(:,j);
       disease_gsSim(i,j)=exp(-rd*((norm(sub,2)).^2));
       
   end 
    
end

end

function [ncp] = NCPLDA(MiFunSim,DiPheSim,mi2diNetwork)
	
	[MnRow,~] = size(MiFunSim);
	[~,DnCol] = size(DiPheSim);
	[RnRow,RnCol] = size(mi2diNetwork);
	%ncp_m = zeros(RnRow,RnCol)+10^-30;
	%ncp_d = zeros(RnRow,RnCol)+10^-30;
    ncp_m = zeros(RnRow,RnCol);
	ncp_d = zeros(RnRow,RnCol);
	ncp =zeros(RnRow,RnCol);
    
    for i = 1:RnRow
		for j = 1:RnCol
			
            if (mi2diNetwork(i,j)==0)
                mi2diNetwork(i,j)=mi2diNetwork(i,j)+10^-30;
            end
            
		end
	end
    
    	for j = 1:RnCol
        	ncp_m(:,j) = (MiFunSim*mi2diNetwork(:,j))/norm(mi2diNetwork(:,j));
    	end

	for i = 1:RnRow
		ncp_d(i,:) = (mi2diNetwork(i,:)*DiPheSim)/norm(mi2diNetwork(i,:));
	end
			
	for i = 1:MnRow
		for j = 1:DnCol
			ncp(i,j) = (ncp_m(i,j) + ncp_d(i,j))/(norm(MiFunSim(i,:))+norm(DiPheSim(:,j)));
		end
	end

	
end

function [ result ] = miRNASS( md_adjmat, disease_ss )
%MIRNASS Summary of this function goes here
%   Detailed explanation goes here
   

rows=size(md_adjmat,1);
result=zeros(rows,rows);

for i=1:rows
    
    idx = find(md_adjmat(i,:)==1);
    
    if isempty(idx)
        continue;
    end
    
    for j=1:i
        
        idy = find(md_adjmat(j,:)==1);
        
        if isempty(idy)
        continue;
        end
        
        sum1=0;
        sum2=0;
        
        for k1=1:size(idx,2)
            
            sum1=sum1+max(disease_ss(idx(1,k1),idy));
            
        end
        
        for k2=1:size(idy,2)
            
            sum2=sum2+max(disease_ss(idx,idy(1,k2)));
            
        end
        
         result(i,j)=(sum1+sum2)/(k1+k2);
         
         result(j,i)=result(i,j);
            
    end
    
    for k=1:rows
       result(k,k)=1; 
    end
    
end
  

end

function [MD_mat_new] = WKNKN( MD_mat, MM_mat, DD_mat, K, r )

[rows,cols]=size(MD_mat);
y_m=zeros(rows,cols);  
y_d=zeros(rows,cols);  

knn_network_m = KNN( MM_mat, K );  %for miRNA
for i = 1 : rows   
         w=zeros(1,K);
        [sort_m,idx_m]=sort(knn_network_m(i,:),2,'descend'); 
        sum_m=sum(sort_m(1,1:K));   
        for j = 1 : K
            w(1,j)=r^(j-1)*sort_m(1,j); 
            y_m(i,:) =  y_m(i,:)+ w(1,j)* MD_mat(idx_m(1,j),:); 
        end                      
            y_m(i,:)=y_m(i,:)/sum_m;              
end

knn_network_d = KNN( DD_mat , K );  %for disease
for i = 1 : cols   
        w=zeros(1,K);
        [sort_d,idx_d]=sort(knn_network_d(i,:),2,'descend');
        sum_d=sum(sort_d(1,1:K));
        for j = 1 : K
            w(1,j)=r^(j-1)*sort_d(1,j);
            y_d(:,i) =  y_d(:,i)+ w(1,j)* MD_mat(:,idx_d(1,j)); 
        end                      
            y_d(:,i)=y_d(:,i)/sum_d;               
end

a1=0;
a2=1;
y_md=(y_m*a1+y_d*a2)/(a1+a2);  

 for i = 1 : rows
     for j = 1 : cols
         MD_mat_new(i,j)=max(MD_mat(i,j),y_md(i,j));
     end    
 end

end

function [ knn_network ] = KNN( network , k )
    [rows, cols] = size( network );
    network= network-diag(diag(network)); 
    knn_network = zeros(rows, cols);
    [sort_network,idx]=sort(network,2,'descend');
    for i = 1 : rows
        knn_network(i,idx(i,1:k))=sort_network(i,1:k);
    end
end


function [ sim ] = combineSim( sim1, sim2 )
%COMBINESIM Summary of this function goes here
%   Detailed explanation goes here

[rows, cols]=size(sim1);

sim=zeros(rows, cols);

 for i=1:rows
     for j=1:cols
        
         
         if (sim1(i,j)==0)
             sim(i,j)=sim2(i,j);
        else
             sim(i,j)=sim1(i,j);
         end
       
        
         %sim(i,j)=(sim1(i,j)+sim2(i,j))/2;
                     
     end
 end

end

