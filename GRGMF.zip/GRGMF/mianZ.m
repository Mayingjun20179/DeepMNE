%%%%%%%%%%%%%GRGMF,5-fold
clc
clear
% % %%%%%%%%%%%%step2�� pair prediction
cv_flag = 1;
M_D = chuli_opt( );
prop = 1;
main_cv(cv_flag,M_D,prop);
% 100.0000    0.1000    0.0100


% %%%%%%%%%%%%step3�� new drug
cv_flag = 2;
M_D = chuli_opt( );
prop = 100;
main_cv(cv_flag,M_D,prop);



% %%%%%%%%%%%%step4��new microbe
cv_flag = 3;
M_D = chuli_opt( );
prop = 100;
main_cv(cv_flag,M_D,prop);


