function P = GRGMF_opt(W,intMat,A_sim,B_sim,option)
% k: Number of neighbors
% max_iter: Maximum number of iteration
% lr: learning rate
% lamb: trade-off parameter for norm-2 regularization on matrix U and V
% K: dimension of the subspace expanded by self-representing vectors(i.e. the dimension for MF)
% beta: trade-off parameter for norm-2 regularization on matrix U and V
% r1: trade-off parameter of graph regularization on nodes in A
% r2: trade-off parameter of graph regularization on nodes in B
% c: constant of the important level for positive sample
% cvs: cross validation setting (1, 2 or 3)


npeps = eps;
add_eps = 0.01;

self.eps = eps;
self.k = 5;
self.n = 0;
self.K = 50;
self.num_factors = self.K;
self.max_iter = 100;
self.lr = 0.1;
self.lamb = 0.0333;
self.beta = 4;
self.r1 = 0.5;
self.r2 = 1;
self.c = 5;
self.loss = num2cell(inf*ones(1,50));
self.WK = self.k;
self.eta = 0.5;

self.imp1 = 3;
self.imp2 = 2;

% W: Mask for training set
%     intMat: complete interaction matrix
%     A_sim: similarity matrix for nodes in A
%     B_sim: similarity matrix for nodes in B
%     seed: random seed to determine a random state
Y = intMat .* W;
[self.num_drugs, self.num_targets] = size(Y);

self.n = self.n+1;
self.A_sim = A_sim;
self.B_sim = B_sim;

% emphasize the diag of similarity matrix
self.A_sim = self.A_sim + self.imp1 * diag(diag(ones(size(A_sim))));
self.B_sim = self.B_sim + self.imp2 * diag(diag(ones(size(B_sim))));

% sparsification
self.A_sim = get_nearest_neighbors(self.A_sim, self.k + 1);
self.B_sim = get_nearest_neighbors(self.B_sim, self.k + 1);

% symmetrization
self.A_sim = (self.A_sim + (self.A_sim)') / 2;
self.B_sim = (self.B_sim + (self.B_sim)') / 2;

% normalization
self.ZA = diag(ones(self.num_drugs,1)./ sum(self.A_sim + add_eps,2))*(self.A_sim + add_eps);
self.ZB = (self.B_sim +add_eps) *  diag(ones(1,self.num_targets)./ sum(self.B_sim + add_eps,1));

% initialization for U and V
seed = 1;
randn('state',seed);
self.U = sqrt(1/self.num_factors)*(randn(self.num_drugs,self.num_factors));
randn('state',seed);
self.V = sqrt(1/self.num_factors)*(randn(self.num_targets,self.num_factors));
[u, s, v] = svd(WKNKN(Y, A_sim, B_sim, self.WK, self.eta));


self.U(:, 1:min(self.num_factors, min(size(Y)))) = u(:, 1:min(self.num_factors, min(size(Y))));
self.V(:, 1:min(self.num_factors, min(size(Y)))) = v(:, 1:min(self.num_factors, min(size(Y))));
clear u s v;

max_iter = self.max_iter;

% Using adam optimizer:
lr = self.lr;
patient = 3;
numiter = max_iter;
minloss = inf;

% store the initial value of ZA ZB U V for later use
init_U = self.U;
init_V = self.V;
init_ZA = self.ZA;
init_ZB = self.ZB;

% A_old refer to the value of ZA in the last iteratio
self.A_old = self.ZA;
self.B_old = self.ZB;
self.U_old = self.U;
self.V_old = self.V;

ZA_best = zeros(size(self.ZA));
ZB_best = zeros(size(self.ZB));
U_best = zeros(size(self.U));
V_best = zeros(size(self.V));
W_all = W;
% iteration
while numiter > 0
    W_1 = W_all;
    Y_p = self.ZA*self.U*transpose(self.V)* self.ZB;
    P = sigmoid(Y_p);
    
    %update U,V
    % reinitialize the optimizer
    [self,P] = update_UV(self,W_1,P,Y,max_iter,numiter);

    % store matrix U, V, ZA and ZB for the currently lowest loss for later use
    self.loss{self.n} = [self.loss{self.n},loss_function(self,Y,W_all)];
    if self.loss{self.n}(end) <  minloss
        ZA_best = self.ZA;        ZB_best = self.ZB;
        U_best = self.U;        V_best = self.V;
        minloss = self.loss{self.n}(end);
    end
    
    % if diverge reinitialize U, V, ZA, ZB and optimizer with half the present learning rate
    if self.loss{self.n}(end) > self.loss{self.n}(1) * 2
        if patient==0
            self.ZA = ZA_best;            self.ZB = ZB_best;
            self.U = U_best;            self.V = V_best;
        end
        % Reinitialization
        self.ZA = init_ZA;
        self.ZB = init_ZB;
        self.U = init_U;
        self.V = init_V;
        lr = lr * 0.5;
        self.lr = lr;
        numiter = max_iter;
        self.loss{self.n}(end) = inf;
        patient = patient-1;
        break;
    end

    
    % Update ZA & ZB
    self = update_ZAB(self,P,W_1,Y);
    % store matrix U, V, ZA and ZB for the currently lowest loss
    self.loss{self.n} = [self.loss{self.n},loss_function(self,Y,W_all)];
    if self.loss{self.n}(end) < minloss
        ZA_best = self.ZA;
        ZB_best = self.ZB;
        U_best = self.U;
        V_best = self.V;
        minloss = self.loss{self.n}(end);
    end
    
    % reinitialize U, V, ZA, ZB and optimizer with half the present learning rate if loss diverge
    if self.loss{self.n}(end) > self.loss{self.n}(1) * 2
        if patient ==  0
            self.ZA = ZA_best;
            self.ZB = ZB_best;
            self.U = U_best;
            self.V = V_best;
        end
        % Reinitialization
        self.ZA =  init_ZA;
        self.ZB = init_ZB;
        self.U = init_U;
        self.V = init_V;
        self.lr = self.lr * 0.5;
        numiter = max_iter;
        self.loss{self.n}(end) = inf;
        patient = patient-1;
        break;
    else
        delta_loss = abs(self.loss{self.n}(end) - self.loss{self.n}(end-1)) / abs(self.loss{self.n}(end-1));
        if delta_loss < 1e-4
            numiter = 0;
        end
    end
    numiter = numiter-1;
end

% retrieve the best U, V, ZA and ZB (at lowest loss)
if self.loss{self.n}(end) > minloss
    self.ZA = ZA_best;
    self.ZB = ZB_best;
    self.U = U_best;
    self.V = V_best;
end

Y_p = self.ZA*self.U*(self.V)'*self.ZB;
P = sigmoid(Y_p);




end


function X = get_nearest_neighbors(S,K1)
%%%%根据公式（8）和（9）构建邻居矩阵
[m, n] = size(S);
X = zeros(m, n);
for i = 1:m
    [~,b] = sort(S(i,:),'descend');
    ii = b(1:min(K1,n));     %只取排名前5的邻居
    X(i,ii) = S(i, ii);
end
end



function L = lap_mat(S)
x = sum(S,2);
L = diag(x) - S;
end



function loss = loss_function(self,Y,W)

% Return the value of loss function
% Args:
% Y: interaction matrix
% W: mask for training set
%
% Returns:
% value of loss function

temp = self.ZA*self.U*(self.V)'*self.ZB;
% logexp(temp > 50) = temp(temp > 50) ;  
% logexp(temp <= 50) = log(exp(temp(temp <= 50)) + 1);
logexp =  log(exp(temp) + 1);


%%%%%目标1
f1 = ((1 + self.c * Y - Y).*logexp - self.c * Y.*temp).*W;
f1 = sum(f1(:));

%%%%%目标2
f2 = self.lamb * (norm(self.U,'fro')^2+norm(self.V,'fro')^2);

%%%%%目标3
f3 =  self.beta * (sum(sum(abs(self.ZA),2).^2)+sum(sum(abs(self.ZB),2).^2));

%%%%%目标4
f4 = self.r1 * trace((self.ZA'*self.U)'*lap_mat(self.A_sim)*self.ZA*self.U)+...
    self.r2 * trace((self.ZB'*self.V)'*lap_mat(self.B_sim)*self.ZB*self.V);

%%%%%总目标
loss = f1+f2+f3+f4;

end



function output = sigmoid(x)
output =1./(1+exp(-x));
end

function [self,P] = update_UV(self,W_1,P,Y,max_iter,numiter)
%P: predict score matrix
%W_1: Mask for training set
%Y： train interaction matrix

U = gpuArray(single(self.U));  U_old = U;
V = gpuArray(single(self.V));  V_old = V;

 
U_m0 = zeros(size(U),'gpuArray'); U_m0 = single(U_m0);
U_v0 = U_m0;
V_m0 = zeros(size(V),'gpuArray'); V_m0 = single(V_m0);
V_v0 =  V_m0;

ZA = gpuArray(single(self.ZA)); 
ZB = gpuArray(single(self.ZB));

PW_1 = gpuArray(single(P .* W_1)); 

A_sim = gpuArray(single(self.A_sim)); 
B_sim = gpuArray(single(self.B_sim)); 
LA_sim = gpuArray(single(lap_mat(A_sim)));
LB_sim = gpuArray(single(lap_mat(B_sim)));

Y = gpuArray(single(Y));
for foo = 1:30
    % compute the derivative of U and V
    deriv_U = ZA'*PW_1*(ZB'*V)+...
        (self.c - 1) * ZA'*(Y .* PW_1)*ZB'*V-...
        self.c*(ZA)'*(Y .* W_1)*(ZB)'*V+...
        2 * self.lamb * U+...
        2*self.r1*(ZA)'* LA_sim * ZA * U ;
    
    deriv_V = ZB*PW_1'*ZA*U+...
        (self.c - 1) * ZB*(Y .* PW_1)'*ZA*U-...
        self.c*ZB*(Y .* W_1)'*ZA*U+...
        2 * self.lamb * V+...
        2*self.r2*ZB* LB_sim*(ZB)'*V;
    
    % update using adam optimizer
    [update,U_m0,U_v0] = opter_delta_U(deriv_U,max_iter - numiter,U_m0,U_v0,self.lr);
    U = U + update;
    [update,V_m0,V_v0] = opter_delta_V(deriv_V,max_iter - numiter,V_m0,V_v0,self.lr);
    V = V + update;
    
    Y_p = ZA * U * (V)'* ZB;
    P = sigmoid(Y_p);    
    PW_1 = gpuArray(single(P .* W_1)); 
    % break the loop if reach converge condition
    ob1 = norm(U - U_old, 'fro') / norm(U_old, 'fro')< 0.01;
    ob2 = norm(V - V_old, 'fro')/ norm(V_old, 'fro')< 0.01;
    if  ob1 & ob2
        break;
    end
    U_old = U;
    V_old = V;
end
self.U = gather(U);
self.V = gather(V);
end



function [update,U_m0,U_v0] = opter_delta_U(deriv,iter,U_m0,U_v0,lr)
beta1 = 0.9;
beta2 = 0.9;
epsilon = 10e-8;
t = (iter + 1);
grad = deriv;
m_t = beta1 * U_m0 + (1 - beta1) * grad;
v_t = beta2 * U_v0 + (1 - beta2) * grad .^ 2;
m_cap = m_t / (1 - beta1 ^ t + eps);
v_cap = v_t / (1 - beta2 ^ t + eps);
update = - lr * m_cap ./ (sqrt(v_cap) + epsilon + eps);
U_m0 = m_t;
U_v0 = v_t;
end

function [update,V_m0,V_v0] = opter_delta_V(deriv,iter,V_m0,V_v0,lr)
beta1 = 0.9;
beta2 = 0.9;
epsilon = 10e-8;
t = (iter + 1);
grad = deriv;
m_t = beta1 * V_m0 + (1 - beta1) * grad;
v_t = beta2 * V_v0 + (1 - beta2) * grad .^ 2;
m_cap = m_t / (1 - beta1 ^ t + eps);
v_cap = v_t / (1 - beta2 ^ t + eps);
update = - lr * m_cap ./ (sqrt(v_cap) + epsilon + eps);
V_m0 = m_t;
V_v0 = v_t;
end


function [self,P] = update_ZAB(self,P,W_1,Y)
U = gpuArray(single(self.U));  
V = gpuArray(single(self.V));  
ZA = gpuArray(single(self.ZA));    A_old = ZA;
ZB = gpuArray(single(self.ZB));    B_old = ZB;
A_sim = gpuArray(single(self.A_sim)); 
B_sim = gpuArray(single(self.B_sim));
Y = gpuArray(single(Y));
PW_1 = gpuArray(single(P .* W_1)); 

for n = 1:30
    temp_p = ((U*V'*ZB)'+abs((U*V'*ZB)'))*0.5;
    temp_n = (abs((U*V'*ZB)')-(U*V'*ZB)') * 0.5;
    UUT_p = (U * U' + abs(U*U')) * 0.5;
    UUT_n = (abs(U * U') - U*U') * 0.5;
    D_AP = PW_1 * temp_p + (self.c - 1) * ((Y .* PW_1)*temp_p)+...
        self.c *(Y .* W_1) * temp_n + self.beta * (2 * ZA)+...
        2 * self.r1 * diag(sum(A_sim,2)) * ZA * UUT_p+...
        2 * self.r1 * A_sim * ZA* UUT_n;
    
    D_AN = PW_1 * temp_n + (self.c - 1) * (Y .* PW_1) * temp_n+...
        + self.c * (Y .* W_1) * temp_p+...
        2 * self.r1 * diag(sum(A_sim,2)) * ZA * UUT_n+...
        2 * self.r1 * A_sim * ZA* UUT_p;
    
    temp_p = ((ZA * U * V')'+abs(ZA * U * V')') * 0.5;
    
    temp_n = (abs((ZA * U * V')')-(ZA * U * V')')*0.5;
    
    
    VVT_p = (V * V' + abs(V * V')) * 0.5;    
    VVT_n = (abs(V * V') - V * V') * 0.5;
    
    D_BP = (temp_p * PW_1 + (self.c - 1) * (temp_p* (Y .* PW_1))+...
        self.c * temp_n * (Y .* W_1)+...
        self.beta * (2 * ZB)+...
        2 * self.r2 * VVT_p * ZB * diag(sum(B_sim,2))+...
        2 * self.r2 * VVT_n * ZB * B_sim);
    
    D_BN = (temp_n * PW_1 + (self.c - 1) * (temp_n* (Y .* PW_1))+...
        self.c * temp_p * (Y .* W_1)+...
        2 * self.r2 * VVT_n * ZB * diag(sum(B_sim,2))+...
        2 * self.r2 * VVT_p * ZB * B_sim);
    
    temp = sum(ZA .* (1./ (D_AP + eps)),2); D_SA = diag(temp);
    E_SA = sum(ZA .* D_AN .* (1./ (D_AP + eps)),2);
    E_SA = repmat(E_SA,1,self.num_drugs);
    
    temp = sum(ZB .* (1./ (D_BP + eps)),1);D_SB = diag(temp);
    E_SB = sum(ZB .* D_BN .* (1./ (D_BP + eps)),1);
    E_SB = repmat(E_SB,self.num_targets,1);
    
    ZA = ZA .* (D_SA*D_AN + 1) ./ (D_SA* D_AP + E_SA + eps);
    ZB = ZB .* (D_BN*D_SB + 1) ./ (D_BP* D_SB + E_SB + eps);
    Y_p = ZA*U*V'* ZB;
    P = sigmoid(Y_p);
    PW_1 = gpuArray(single(P .* W_1)); 
    % break the loop if reach convergence condition
    ob3 = norm(ZA - A_old, 'fro') / norm(A_old, 'fro')< 0.01;
    ob4 = norm(ZB - B_old, 'fro')/ norm(B_old, 'fro')< 0.01;
    
    if ob3 & ob4
        break;
    end
    A_old = ZA;
    B_old = ZB;
end
self.ZA = gather(ZA);
self.ZB = gather(ZB);

end

function Y_tem = WKNKN(Y, SD, ST, K, eta)
Yd = zeros(size(Y));
Yt = Yd;
wi = zeros(K,1);
wj = zeros(1,K);
[num_drugs, num_targets] = size(Y);
for i = 1:num_drugs
    [~,ind] = sort(SD(i,:),'descend');
    dnn_i = ind(2:K+1);
    Zd = sum(SD(i, dnn_i));
    for ii = 1:K
        wi(ii) = eta^ii* SD(i,dnn_i(ii));
    end
    if abs(Zd)>eps
        Yd(i,:) = sum(repmat(wi,1,num_targets).*Y(dnn_i,:)) / Zd;
    end
end

for j = 1:num_targets
    [~,ind] = sort(ST(j,:),'descend');
    tnn_j = ind(2:K+1);
    Zt = sum(ST(j, tnn_j));
    for jj = 1:K
        wj(jj) = eta^jj * ST(j,tnn_j(jj));
    end
    if abs(Zt)>eps
        Yt(:,j) = sum(repmat(wj,num_drugs,1).*Y(:,tnn_j),2) / Zt;
    end
end

Ydt = (Yd + Yt)/2;
Y_tem = max(Ydt,Y);
end

