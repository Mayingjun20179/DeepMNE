%%%将drug_micro_MASI.mat保存为txt文件
function M_D = chuli_opt( )
load('lnc_dis_inf2019.mat')
M_D.interaction = lnc_dis_inf2019.interaction;
M_D.lnc_sim = lnc_dis_inf2019.lnc_inf.d2sim;
M_D.dis_sim = lnc_dis_inf2019.dis_inf.tree_sim;
end