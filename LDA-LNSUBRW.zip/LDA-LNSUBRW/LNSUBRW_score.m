function scores = LNSUBRW_score(DATA,cv_data)

train_set = DATA.interaction.*cv_data{1};   %ѵ������

Wdd  = DATA.dis_inf.tree_sim;


Wrr_v=lncRNAfunsim(Wdd,train_set);
y_train=WKNKN( train_set, Wrr_v, Wdd, 5, 1 );

similairty_matrix2=LNS(y_train',0,50,'regulation2');


similairty_matrix1=LNS(y_train,0,90,'regulation2');


F_1 = BR(y_train,similairty_matrix1,similairty_matrix2,5,4,0.2);

%��Σ��������յĵ÷�
test_data = cv_data{2};
scores = arrayfun(@(x,y)tx_opt(F_1,x,y),test_data(:,1),test_data(:,2));


end

function c = tx_opt(A,b,c)
c = A(b,c);
end

function [mms]=lncRNAfunsim(DDS,M)
mrows=size(M,1);
mms=zeros(mrows,mrows);
for i=1:mrows
    index1=find(M(i,:)==1);
    if length(index1)==0
        mms(i,:)=0;
    else
        for j=1:mrows
            index2=find(M(j,:)==1);
            if length(index2)==0
                mms(i,j)=0;
            else
                sim1=zeros(1,length(index1));
                for m=1:length(index1)
                    sim1(m)=max(DDS(index2,index1(m))');
                end
                sim2=zeros(1,length(index2));
                for n=1:length(index2)
                    sim2(n)=max(DDS(index1,index2(n))');
                end
                mms(i,j)=(sum(sim1)+sum(sim2))/(length(index1)+length(index2));
            end
        end
    end
end
for k=1:mrows
    mms(k,k)=1;
end
end

function [MD_mat_new] = WKNKN( MD_mat, MM_mat, DD_mat, K, r )
%��ԭʼ������и���
[rows,cols]=size(MD_mat);
y_m=zeros(rows,cols);
y_d=zeros(rows,cols);
%knn����ѡ��lncrna��k������ھ�
knn_network_m = KNN( MM_mat, K );  %for lncRNA
for i = 1 : rows
    w=zeros(1,K);
    [sort_m,idx_m]=sort(knn_network_m(i,:),2,'descend');
    sum_m=sum(sort_m(1,1:K));
    for j = 1 : K
        w(1,j)=r^(j-1)*sort_m(1,j);
        y_m(i,:) =  y_m(i,:)+ w(1,j)* MD_mat(idx_m(1,j),:);
    end
    y_m(i,:)=y_m(i,:)/sum_m;
end

knn_network_d = KNN( DD_mat , K );  %for disease
for i = 1 : cols
    w=zeros(1,K);
    [sort_d,idx_d]=sort(knn_network_d(i,:),2,'descend');
    sum_d=sum(sort_d(1,1:K));
    for j = 1 : K
        w(1,j)=r^(j-1)*sort_d(1,j);
        y_d(:,i) =  y_d(:,i)+ w(1,j)* MD_mat(:,idx_d(1,j));
    end
    y_d(:,i)=y_d(:,i)/sum_d;
end
%��Ӧ��α�����ymd
a1=1;
a2=1;
y_md=(y_m*a1+y_d*a2)/(a1+a2);
%�������ֵ��ȡ��0����lnc�ͼ����Ľ����������׵�ƽ��ֵ
for i = 1 : rows
    for j = 1 : cols
        MD_mat_new(i,j)=max(MD_mat(i,j),y_md(i,j));
    end
end

end

function [ knn_network ] = KNN( network , k )
[rows, cols] = size( network );
network= network-diag(diag(network));
knn_network = zeros(rows, cols);
[sort_network,idx]=sort(network,2,'descend');%�н�������
for i = 1 : rows
    knn_network(i,idx(i,1:k))=sort_network(i,1:k);
end
end



function W=LNS(feature_matrix,tag,neighbor_num,regulation) %% Using the method of label propagation to predict the interaction
distance_matrix=calculate_instances(feature_matrix);
nearst_neighbor_matrix=calculate_neighbors(distance_matrix,neighbor_num);
W=optimization_similairty_matrix(feature_matrix,nearst_neighbor_matrix,tag,regulation);
end

%%'regulation1':LN similarity, 'regulation2': RLN similarity
function W=optimization_similairty_matrix(feature_matrix,nearst_neighbor_matrix,tag,regulation) %%quadratic programming���ι滮
row_num=size(feature_matrix,1);
W=zeros(1,row_num); %Ȩ��
if tag==1
    row_num=1;
end
for i=1:row_num
    nearst_neighbors=feature_matrix(logical(nearst_neighbor_matrix(i,:)'),:);
    neighbors_num=size(nearst_neighbors,1);
    G1=repmat(feature_matrix(i,:),neighbors_num,1)-nearst_neighbors; %�൱�ڹ�ʽ���G
    G2=repmat(feature_matrix(i,:),neighbors_num,1)'-nearst_neighbors';
    if regulation=='regulation2'
        G_i=G1*G2+eye(neighbors_num);
    end
    if regulation=='regulation1'
        G_i=G1*G2;
    end
    H=2*G_i;
    f=[];
    A=[];
    if isempty(H)
        A;
    end
    
    b=[];
    Aeq=ones(neighbors_num,1)';
    beq=1;
    lb=zeros(neighbors_num,1);
    ub=[];
    options=optimset('Display','off');
    [w,fval]= quadprog(H,f,A,b,Aeq,beq,lb,ub,[],options);
    w=w';
    W(i,logical(nearst_neighbor_matrix(i,:)))=w;
end
end

function distance_matrix=calculate_instances(feature_matrix) %%calculate the distance between each feature vector of lncRNAs or disease.
[row_num,col_num]=size(feature_matrix);
distance_matrix=zeros(row_num,row_num);  %��������ִ�ʱ�����Lnc����disease�ľ���
for i=1:row_num
    for j=i+1:row_num
        distance_matrix(i,j)=sqrt(sum((feature_matrix(i,:)-feature_matrix(j,:)).^2)); %ŷ�Ͼ��룬������Lnc�պ���ÿһ��lnc������ľ���
        distance_matrix(j,i)=distance_matrix(i,j);
    end
    distance_matrix(i,i)=col_num;
end
end

function nearst_neighbor_matrix=calculate_neighbors(distance_matrix,neighbor_num)%% calculate the nearest K neighbors
[sv,si]=sort(distance_matrix,2,'ascend'); %����svΪ��������Ľ����siΪ���index��dim=2ʱΪ�������У�����distance�����ÿ�а���������
[row_num,col_num]=size(distance_matrix);
nearst_neighbor_matrix=zeros(row_num,col_num);
index=si(:,1:neighbor_num);
for i=1:row_num
    nearst_neighbor_matrix(i,index(i,:))=1; %����ѡȡ���ھ���ŵ���1
end
end

function [Rt]=BR(A,Wrr,Wdd,L1,L2,alpha)

normWrr = normFun1(Wrr);
normWdd = normFun1(Wdd);

R0=A/sum(A(:));
Rt=R0;

%bi-random walk on the heterogeneous network
for t=1:max(L1,L2)
    
    ftl = 0;
    ftr = 0;
    
    %random walk on the lncRNA similarity network
    if(t<=L1)
        nRtleft =(1- alpha) * normWrr * Rt + alpha*R0;
        ftl = 1;
    end
    %random walk on the disease similarity network
    if(t<=L2)
        nRtright = (1-alpha) *  Rt * normWdd + alpha*R0;
        ftr = 1;
    end
    
    %Rt: predictive association scores between each lncRNA-disease pair
    Rt =  (ftl*nRtleft + ftr*nRtright)/(ftl + ftr);
    
end
end



function [M]=normFun1(M)
for i=1:length(M)         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    z=find(M(:,i)~=0);
    M(z,i)=M(z,i)./sum(M(z,i));
end
end



